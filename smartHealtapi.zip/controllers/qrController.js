const QR = require('../models/cotizacion');

module.exports = {
    async findByUser(req, res, nect){
        try{
            const id_user = req.params.id_user
            const data = await Cotizacion.findByUser(id_user);
            // console.log(`Cotizacion ${JSON.stringify(data)}`);
            return res.status(201).json(data);
            
        }catch(error){
            console.log(`Error al obtener cotizaciones ${error}`);
            return res.status(501).json({
                message: 'Hubo un error al tratar de obtener las cotizaciones',
                error: error,
                success: false
            })
        }


    }
}