const db = require('../config/config');

const Qr = {};

Qr.findByUser = (id_user) => {
    const sql = `
        SELECT
            id,
            id_user,
            product,
            area,
            tecnologias,
            estado_via,
            ubicacion,
            coordenadas,
            toneladas,
            origen,
            destino,
            costo,
            medio
        FROM
            cotizaciones
        WHERE
            id_user = $1
    `;
    return db.manyOrNone(sql, id_user);
}